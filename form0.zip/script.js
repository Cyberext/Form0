// Form Validation and Interaction
document.addEventListener('DOMContentLoaded', function() {
    
    // Get form elements
    const form = document.getElementById('contactForm');
    const fullNameInput = document.getElementById('fullName');
    const emailInput = document.getElementById('email');
    const phoneInput = document.getElementById('phone');
    const subjectInput = document.getElementById('subject');
    const messageTextarea = document.getElementById('message');
    const privacyCheckbox = document.getElementById('privacy');
    const submitBtn = document.getElementById('submitBtn');
    const charCount = document.getElementById('charCount');
    const successMessage = document.getElementById('successMessage');
    const newMessageBtn = document.getElementById('newMessageBtn');

    // Validation patterns
    const patterns = {
        name: /^[a-zA-Z\s]{2,50}$/,
        email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
        phone: /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/,
        subject: /^.{3,100}$/
    };

    // Validation messages
    const messages = {
        fullName: {
            empty: 'Full name is required',
            invalid: 'Please enter a valid name (2-50 characters, letters only)'
        },
        email: {
            empty: 'Email address is required',
            invalid: 'Please enter a valid email address'
        },
        phone: {
            invalid: 'Please enter a valid phone number'
        },
        subject: {
            empty: 'Subject is required',
            invalid: 'Subject must be between 3 and 100 characters'
        },
        message: {
            empty: 'Message is required',
            tooShort: 'Message must be at least 10 characters',
            tooLong: 'Message cannot exceed 500 characters'
        },
        privacy: {
            unchecked: 'You must agree to the privacy policy'
        }
    };

    // Real-time validation for full name
    fullNameInput.addEventListener('input', function() {
        validateField(this, 'fullName');
    });

    fullNameInput.addEventListener('blur', function() {
        if (this.value.trim() === '') {
            showError(this, messages.fullName.empty);
        }
    });

    // Real-time validation for email
    emailInput.addEventListener('input', function() {
        validateField(this, 'email');
    });

    emailInput.addEventListener('blur', function() {
        if (this.value.trim() === '') {
            showError(this, messages.email.empty);
        }
    });

    // Real-time validation for phone (optional)
    phoneInput.addEventListener('input', function() {
        if (this.value.trim() !== '') {
            validateField(this, 'phone');
        } else {
            clearValidation(this);
        }
    });

    // Real-time validation for subject
    subjectInput.addEventListener('input', function() {
        validateField(this, 'subject');
    });

    subjectInput.addEventListener('blur', function() {
        if (this.value.trim() === '') {
            showError(this, messages.subject.empty);
        }
    });

    // Real-time validation and character count for message
    messageTextarea.addEventListener('input', function() {
        const length = this.value.length;
        charCount.textContent = length;
        
        const countElement = charCount.parentElement;
        countElement.classList.remove('warning', 'error');
        
        if (length > 450) {
            countElement.classList.add('warning');
        }
        if (length > 500) {
            countElement.classList.add('error');
        }
        
        validateMessage(this);
    });

    messageTextarea.addEventListener('blur', function() {
        if (this.value.trim() === '') {
            showError(this, messages.message.empty);
        }
    });

    // Privacy checkbox validation
    privacyCheckbox.addEventListener('change', function() {
        if (this.checked) {
            clearValidation(this);
        } else {
            showError(this, messages.privacy.unchecked);
        }
    });

    // Form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Validate all fields
        const isNameValid = validateField(fullNameInput, 'fullName');
        const isEmailValid = validateField(emailInput, 'email');
        const isPhoneValid = phoneInput.value.trim() === '' || validateField(phoneInput, 'phone');
        const isSubjectValid = validateField(subjectInput, 'subject');
        const isMessageValid = validateMessage(messageTextarea);
        const isPrivacyChecked = validatePrivacy(privacyCheckbox);
        
        // If all validations pass
        if (isNameValid && isEmailValid && isPhoneValid && isSubjectValid && isMessageValid && isPrivacyChecked) {
            submitForm();
        } else {
            // Scroll to first error
            const firstError = form.querySelector('.form-group.error');
            if (firstError) {
                firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }
    });

    // Validate individual field
    function validateField(input, fieldName) {
        const value = input.value.trim();
        const formGroup = input.closest('.form-group');
        
        if (value === '' && fieldName !== 'phone') {
            showError(input, messages[fieldName].empty);
            return false;
        }
        
        if (value !== '' && !patterns[fieldName].test(value)) {
            showError(input, messages[fieldName].invalid);
            return false;
        }
        
        showSuccess(input);
        return true;
    }

    // Validate message field
    function validateMessage(textarea) {
        const value = textarea.value.trim();
        const formGroup = textarea.closest('.form-group');
        
        if (value === '') {
            showError(textarea, messages.message.empty);
            return false;
        }
        
        if (value.length < 10) {
            showError(textarea, messages.message.tooShort);
            return false;
        }
        
        if (value.length > 500) {
            showError(textarea, messages.message.tooLong);
            return false;
        }
        
        clearValidation(textarea);
        return true;
    }

    // Validate privacy checkbox
    function validatePrivacy(checkbox) {
        const formGroup = checkbox.closest('.form-group');
        
        if (!checkbox.checked) {
            showError(checkbox, messages.privacy.unchecked);
            return false;
        }
        
        clearValidation(checkbox);
        return true;
    }

    // Show success state
    function showSuccess(input) {
        const formGroup = input.closest('.form-group');
        formGroup.classList.remove('error');
        formGroup.classList.add('valid');
        
        const errorMessage = formGroup.querySelector('.error-message');
        errorMessage.textContent = '';
    }

    // Show error state
    function showError(input, message) {
        const formGroup = input.closest('.form-group');
        formGroup.classList.remove('valid');
        formGroup.classList.add('error');
        
        const errorMessage = formGroup.querySelector('.error-message');
        errorMessage.textContent = message;
    }

    // Clear validation state
    function clearValidation(input) {
        const formGroup = input.closest('.form-group');
        formGroup.classList.remove('error', 'valid');
        
        const errorMessage = formGroup.querySelector('.error-message');
        errorMessage.textContent = '';
    }

    // Submit form
    function submitForm() {
        // Show loading state
        submitBtn.disabled = true;
        submitBtn.classList.add('loading');
        
        // Simulate form submission (replace with actual API call)
        setTimeout(() => {
            // Get form data
            const formData = {
                fullName: fullNameInput.value.trim(),
                email: emailInput.value.trim(),
                phone: phoneInput.value.trim(),
                subject: subjectInput.value.trim(),
                message: messageTextarea.value.trim(),
                timestamp: new Date().toISOString()
            };
            
            // Log form data (in production, send to server)
            console.log('Form submitted:', formData);
            
            // Show success message
            form.style.display = 'none';
            successMessage.classList.add('show');
            
            // Reset button state
            submitBtn.disabled = false;
            submitBtn.classList.remove('loading');
            
            // Scroll to success message
            successMessage.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 1500);
    }

    // Reset form for new message
    newMessageBtn.addEventListener('click', function() {
        // Hide success message
        successMessage.classList.remove('show');
        
        // Show form
        form.style.display = 'flex';
        
        // Reset form
        form.reset();
        
        // Clear all validation states
        const formGroups = form.querySelectorAll('.form-group');
        formGroups.forEach(group => {
            group.classList.remove('valid', 'error');
            const errorMessage = group.querySelector('.error-message');
            if (errorMessage) {
                errorMessage.textContent = '';
            }
        });
        
        // Reset character count
        charCount.textContent = '0';
        charCount.parentElement.classList.remove('warning', 'error');
        
        // Scroll to top of form
        form.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });

    // Prevent form submission on Enter key in input fields
    const inputs = form.querySelectorAll('input');
    inputs.forEach(input => {
        input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
            }
        });
    });

    // Auto-format phone number (optional enhancement)
    phoneInput.addEventListener('input', function(e) {
        let value = this.value.replace(/\D/g, '');
        
        if (value.length > 0) {
            if (value.length <= 3) {
                this.value = value;
            } else if (value.length <= 6) {
                this.value = value.slice(0, 3) + ' ' + value.slice(3);
            } else {
                this.value = value.slice(0, 3) + ' ' + value.slice(3, 6) + ' ' + value.slice(6, 10);
            }
        }
    });

    // Add focus effect to form groups
    const allInputs = form.querySelectorAll('.form-input, .form-textarea');
    allInputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.closest('.form-group').classList.add('focused');
        });
        
        input.addEventListener('blur', function() {
            this.closest('.form-group').classList.remove('focused');
        });
    });

    console.log('Contact Form - Initialized');
    console.log('Features: Real-time validation, Character counter, Auto-formatting');
    console.log('Developer: Rogen Tonderai Bharani');
});